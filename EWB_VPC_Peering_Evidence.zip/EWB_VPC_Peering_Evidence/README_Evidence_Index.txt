EWB VPC Peering Project — Evidence Index

01_VPC_Configuration
- Route tables overview screenshot

02_VPC_Peering
- Active VPC peering connection screenshot

03_EC2_Instances
- Three EC2 instances running; 3/3 status checks passed

04_SSH_Connectivity
- SSH login to App-B through the bastion host

05_Ping_Test_Results
- App-A to App-B ping success
- App-B to App-A ping success

06_Failure_and_Recovery
- Controlled ICMP failure test
- Connectivity restored after the ICMP rule was restored

Note: Add a bastion SSH screenshot and any separate App-A SSH screenshot if available.
Before publishing screenshots in a public repository, redact the AWS account ID and any other identifying details.
